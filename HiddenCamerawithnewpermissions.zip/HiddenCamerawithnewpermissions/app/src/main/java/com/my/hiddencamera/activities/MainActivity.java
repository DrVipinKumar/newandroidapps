package com.my.hiddencamera.activities;

import androidx.activity.result.ActivityResult;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import	androidx.core.content.ContextCompat;
import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.NonNull;

import android.os.Environment;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.my.hiddencamera.R;
import com.my.hiddencamera.listeners.PictureCapturingListener;
import com.my.hiddencamera.services.APictureCapturingService;
import com.my.hiddencamera.services.PictureCapturingServiceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import android.provider.*;
import android.net.*;
import android.os.*;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.annotation.*;
import androidx.*;
import android.Manifest.permission;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;


public class MainActivity extends AppCompatActivity implements PictureCapturingListener, ActivityCompat.OnRequestPermissionsResultCallback {

    private static final String[] requiredPermissions = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.CAMERA
    };
    private static final int PERMISSION_REQUEST_CODE = 1;
    //private static final int MY_CAMERA_REQUEST_CODE = 100;

    private ImageView uploadBackPhoto;
    private ImageView uploadFrontPhoto;
    private Intent intent = new Intent ();
    //ActivityResultLauncher<Intent> activityResultLauncher;
    String[] permission = {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};

    //The capture service
    private APictureCapturingService pictureService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_main);
        checkPermissions ();
        uploadBackPhoto = (ImageView) findViewById (R.id.backIV);
        uploadFrontPhoto = (ImageView) findViewById (R.id.frontIV);
        final Button btn = (Button) findViewById (R.id.startCaptureBtn);
        // getting instance of the Service from PictureCapturingServiceImpl
        pictureService = PictureCapturingServiceImpl.getInstance (this);
        if (checkPermissions ()) {
            btn.setOnClickListener (v -> {
                showToast ("Starting capture!");
                pictureService.startCapturing (this);
            });
        } else {
            requestPermission ();
        }
    }

    private void showToast(final String text) {
        runOnUiThread (() ->
                Toast.makeText (getApplicationContext (), text, Toast.LENGTH_SHORT).show ()
        );
    }

    /**
     * We've finished taking pictures from all phone's cameras
     */
    @Override
    public void onDoneCapturingAllPhotos(TreeMap<String, byte[]> picturesTaken) {
        if (picturesTaken != null && !picturesTaken.isEmpty ()) {
            showToast ("Done capturing all photos!");
            return;
        }
        showToast ("No camera detected!");
    }

    /**
     * Displaying the pictures taken.
     */
    @Override
    public void onCaptureDone(String pictureUrl, byte[] pictureData) {
        if (pictureData != null && pictureUrl != null) {
            runOnUiThread (() -> {
                final Bitmap bitmap = BitmapFactory.decodeByteArray (pictureData, 0, pictureData.length);
                final int nh = (int) (bitmap.getHeight () * (512.0 / bitmap.getWidth ()));
                final Bitmap scaled = Bitmap.createScaledBitmap (bitmap, 512, nh, true);
                if (pictureUrl.contains ("0_pic.jpg")) {
                    uploadBackPhoto.setImageBitmap (scaled);
                } else if (pictureUrl.contains ("1_pic.jpg")) {
                    uploadFrontPhoto.setImageBitmap (scaled);
                }
            });
            showToast ("Picture saved to " + pictureUrl);
        }
    }

    //activityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),new ActivityResultCallback<ActivityResult>()

    //{


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2296) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                if (android.os.Environment.isExternalStorageManager()) {
                    // perform action when allow permission success
                } else {
                    Toast.makeText(this, "Allow permission for storage access!", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0) {
                    boolean READ_EXTERNAL_STORAGE = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean WRITE_EXTERNAL_STORAGE = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                    boolean CAMERA = grantResults[2] == PackageManager.PERMISSION_GRANTED;

                    if (READ_EXTERNAL_STORAGE && WRITE_EXTERNAL_STORAGE && CAMERA) {
                        // perform action when allow permission success
                    } else {
                        Toast.makeText(this, "Allow permission for storage access!", Toast.LENGTH_SHORT).show();
                    }
                }
                break;
        }
        //if (requestCode == MY_CAMERA_REQUEST_CODE) {
         //   if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
          //      Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();
           // } else {
             //   Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();
            //}
       // }
    }

    /**
     * checking  permissions at Runtime.
     */
    //@TargetApi(Build.VERSION_CODES.M)
    private boolean checkPermissions() {

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return Environment.isExternalStorageManager();

        } else {

            int result = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE);
            int result1 = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
            int result2 = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA);
            return result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED && result2 == PackageManager.PERMISSION_GRANTED;
        }
    }

    private void requestPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                Intent intent = new Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intent.addCategory("android.intent.category.DEFAULT");
                intent.setData(android.net.Uri.parse(String.format("package:%s",getApplicationContext().getPackageName())));
                //activityResultLauncher.launch(intent);
                startActivityForResult (intent,2296);

            } catch (Exception e) {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                //startActivityForResult(intent, 2296);
                //activityResultLauncher.launch(intent);
                startActivityForResult(intent,2296);
            }
        } else {
            //below android 11
            ActivityCompat.requestPermissions(MainActivity.this, permission, PERMISSION_REQUEST_CODE);
        }
    }


}

